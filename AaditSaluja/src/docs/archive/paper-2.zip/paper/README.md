# Draft Paper

First USENIX-format draft for the CephFS metadata project.

Files:

- `main.tex`: paper draft.
- `refs.bib`: bibliography, including TODO placeholder entries for related work
  whose exact citation metadata still needs to be verified.
- `usenix-2020-09.sty`: USENIX style file downloaded from the official USENIX
  paper-template page.
- `usenix2019_v3.1.tex`: official USENIX sample LaTeX source, kept as a local
  reference.
- `main.pdf`: compiled draft output after `make`.

Build:

```sh
cd paper
make
```

Current TODOs inside the draft:

- Replace the author block and check the target venue or class policy on
  anonymity.
- The draft now uses the completed 63-job matrix summarized in
  `results/cloudlab-paperready-20260506-3x/PAPER_READY_RESULTS.md` and includes
  PDF plots with error bars from `docs/figures/*errorbars.pdf`.
- Refresh final numbers from the follow-up scheduler after it finishes:
  `predictor_nolearn`, `predictor_false_hot_churn`, extra `r3`/`r4` repeats,
  and `scaled_hotcold_cold90_access10_20k`.
- Verify exact Mantle, Lunule+, and DeltaFS bibliography entries.
- Add artifact URL or archive hash if submitting outside the local repo.
- Add acknowledgments and AI-use text if required.
